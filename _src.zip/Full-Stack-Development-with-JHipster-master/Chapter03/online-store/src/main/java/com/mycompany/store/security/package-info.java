/**
 * Spring Security configuration.
 */
package com.mycompany.store.security;
