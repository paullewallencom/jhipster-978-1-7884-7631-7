/**
 * Service layer beans.
 */
package com.mycompany.store.service;
